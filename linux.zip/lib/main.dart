import 'package:flutter/material.dart';
import 'frontend/SignUp.dart';
import 'frontend/TestScreen.dart';

void main() {
  runApp(const CareerApp());
}

class CareerApp extends StatelessWidget {
  const CareerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Career App', home: Test2Page());
  }
}

class StartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('main')),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            ElevatedButton(
              child: const Text('Next'),
              onPressed: () {
                Navigator.of(
                  context,
                ).push(MaterialPageRoute<void>(builder: (context) => SignUp()));
              },
            ),
          ],
        ),
      ),
    );
  }
}
