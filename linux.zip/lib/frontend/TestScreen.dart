import 'package:flutter/material.dart';
import 'SignUp.dart';

class TestPage extends StatefulWidget {
  const TestPage({super.key});

  @override
  State<TestPage> createState() => _TestPageState();
}

class _TestPageState extends State<TestPage> {
  @override
  Widget build(BuildContext) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            color: Colors.deepPurpleAccent,
            height: 600,
            child: Center(
              child: Icon(
                Icons.image_outlined,
                size: 50,
                color: const Color.fromARGB(229, 255, 255, 255),
              ),
            ),
          ),
          Container(
            color: const Color.fromARGB(255, 210, 208, 208),
            height: 300,
            child: Column(
              children: [
                SizedBox(height: 10),

                Text(
                  "Главный текст",
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.left,
                ),

                SizedBox(height: 10),

                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (context) => SignUp()),
                    );
                  },
                  child: const Text("Next"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Test2Page extends StatefulWidget {
  const Test2Page({super.key});

  @override
  State<Test2Page> createState() => _Test2PageState();
}

class _Test2PageState extends State<Test2Page> {
  @override
  Widget build(BuildContext) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: Colors.deepPurpleAccent,
              height: 600,
              child: Center(
                child: Icon(
                  Icons.image_outlined,
                  size: 50,
                  color: const Color.fromARGB(229, 255, 255, 255),
                ),
              ),
            ),
            Container(
              child: Column(
                children: [
                  SizedBox(height: 10),

                  Text(
                    'Главный Текст',
                    style: TextStyle(fontSize: 16),
                    textAlign: TextAlign.left,
                  ),

                  SizedBox(height: 10),

                  Text(
                    'текст текст текст',
                    style: TextStyle(fontSize: 5),
                    textAlign: TextAlign.left,
                  ),

                  SizedBox(height: 10),

                  ElevatedButton(
                    child: const Text(
                      "Next",
                      style: TextStyle(color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(builder: (context) => SignUp()),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
