package com.example.career_compasp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
